<script>
import { ref } from 'vue';

export default {
    name: 'App',
    
    setup() {
    
      

      const inicio = ref([
            { linkini: '#home', textinicio: 'Inicio'},
            { linkini: '#acerca-mi', textinicio: 'Acerca de mi'},
            { linkini: '#Habilidades', textinicio: 'Habilidades'},
            { linkini: '#experiencia', textinicio: 'Experiencia'}
        ]);
      const imagesexp = ref ([{titulo: 'Integrante de Centro de Servicios de Tecnologías de Información', link: 'https://media.licdn.com/dms/image/C5603AQHh8rtsOrfiqA/profile-displayphoto-shrink_800_800/0/1517623223582?e=2147483647&v=beta&t=icMctGEoXReg5b0ucgLzghn53iZ1U4z5r7agj4HGZyw', textlink: 'csti'},
      {titulo: 'Curso de ciberseguridad:', link: 'https://cdn.discordapp.com/attachments/1051171491313614848/1163597784226738186/curso2.PNG?ex=654027e2&is=652db2e2&hm=407763c0b912d2b58cc9f698de05270e671521a3b2e67815822195f2e9b5562b&', textlink: 'curso1'},
      {titulo: 'Curso de configuracion y administracion de servidores con windows:', link: 'https://cdn.discordapp.com/attachments/1051171491313614848/1163597784470011954/curso1.PNG?ex=654027e2&is=652db2e2&hm=5f127dc9b94a6465f104cc3f3b148f8c0da089543579f22e6737ca902001fa54&', textlink: 'curso2'}])

      
        
     return {
            inicio,imagesexp, Perfilimage: {
        src:"https://cdn.discordapp.com/attachments/1051171491313614848/1163595559333007450/20230921_094842.jpg?ex=654025cf&is=652db0cf&hm=07aea79ae0de5c94fe293531cb348902e34c79eb3218b219b334123c2938ae7e&", 
        alt:"Foto de perfil"}, acercami:["Mi nombre completo es Griselda Estefania Encinas Torres, estudio en la universidad de sonora, actualmente estoy en 9 semestre en la carrera de ingenieria en Sistemas de la Informacion","Tengo 22 años, naci en hermosillo, Sonora","Soy una persona responsable, paciente, comunicativa, de mente abierta e interesada en nuevos conocimientos"],
        interes:["En mis tiempos libres me gusta leer libros, ver series o videojuegos", "Tengo mucho interes en la gastronomia y a las cosas dulces que no he probado"],
        biografia:["Actualmente tengo 22 años y sigo cursando mi noveno semestre en la UNISON, mi familia se conforma con mis padres y mi hermana mayor,me gustan los animales, por lo que ha lo largo de mi vida he tenido un gato llamado silvestre, un pollito llamado pollo, una perrita llamada kiara y una tortuga llamada alguita.Soy muy hogareña por lo que casi no me gusta salir a menos que fuera a comer "],
        };
    }
}
</script>

<template>
  <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Proyecto parcial 1</title>
</head>
<body>
    <header>
            

           <nav id="menu">
            <ul>
                <li v-for="item in inicio"><a :href="item.linkini"><h1>{{ item.textinicio }}</h1></a></li>
                 
                
            </ul> 
            
        </nav>
       
    </header>
    <br>
    <main>
         <div class="division">
                    <h1>Inicio</h1>
                </div>
        <section id="home">
            <nav class="Perfil">
                
                <img :="Perfilimage">

            </nav>
            <nav class="Info-Perfil">
                <h2>Bienvenidos a mi pagina, soy Estefania <br> A continuacion se mostrara informacion acerca de mi</h2>
                
            </nav>
            
        </section>
        <div class="division">
            <h1>Acerca de mi</h1>
        </div>   
        <section id="acerca-mi">
            
            <nav class="contenido-mi">
                <h2 v-for="item in acercami"> {{ item }}</h2>
                <br>
                
            
            <h1>Mis intereses</h1>
            
                
                <h2 v-for="item in interes"> {{ item }}</h2>
                <br>

            
            <h1>Biografia</h1>
            <h2 v-for="item in biografia"> {{ item }}</h2>
                
              </nav>
            
        </section>
        <div class="division">
            <h1>Habilidades</h1>
        </div>   
        
                
        
        <section id="Habilidades">
            
            
                <nav class="web">
                    <h1>Desarrollo web:</h1>
                    <br>
                    <ul>
                        <li><i class="fa-brands fa-js" style="color: #e5e817;"></i> Javascript- En aprendizaje</li>
                        <br>
                        <li><i class="fa-brands fa-css3-alt" style="color: #3178f2;"></i> Css- En aprendizaje</li>
                        <br>
                        <li><i class="fa-brands fa-php" style="color: #020203;"></i> Php- En aprendizaje</li>
                        <br>
                        <li><i class="fa-brands fa-html5" style="color: #ec6409;"></i> Html- En aprendizaje</li>

                    </ul>

                </nav>
                <nav class="desarrollador">
                    <h1>Desarrollo de aplicaciones:</h1>
                    <br>
                    <ul>
                        <li><i class="fa-brands fa-java" style="color: #f42525;"></i> Java- Intermedio</li>
                        <br>
                        <li><i class="fa-brands fa-python" style="color: #f0ff1a;"></i> Python- Intermedio </li>
                        <br>
                        <li><i class="fa-solid fa-c" style="color: #9f2cdd;"></i> C#- Intermedio</li>
                    </ul>
                </nav>
            
                
                    
            
                <nav class="movil">
                    <h1>Desarrollo movil:</h1>
                    <br>
                    <ul>
                    <li><i class="fa-brands fa-android" style="color: #05ff16;"></i> Android Studio- En aprendizaje</li>
                    </ul>
                </nav> 
            <nav class="h-otros">
                <h1>Idiomas:</h1>
                <br>
                <ul>
                    <li>Ingles: 7</li>
                    <br>
                    <li>Aleman:1</li>
                </ul>
                

            </nav>
                
        </section>
        <div class="division">
            <h1>Experiencia</h1>
        </div>   
        <section id="experiencia">
            <nav class="lista-exp" v-for="item in imagesexp" >
                <h2 >{{item.titulo}}</h2>
                <nav class="exp">
                <img :src="item.link" :alt="item.textlink">
                </nav>
                
            </nav>

        </section>
        


    </main>
    <footer>

<section id="contactos">
    <br>
    <h1>Contactos</h1>
    <br>
            <nav class="redes">
                
                <a href="https://github.com/GriseldaE"><i class="fa-brands fa-github" style="color: #bd30d9;"></i></a> 
                <a href="https://wa.me/526624234542"><i class="fa-brands fa-whatsapp" style="color: #34e411;"></i></a>
                <a href="https://www.instagram.com/estefaniaz411/"><i class="fa-brands fa-instagram" style="color: #e53ece;"></i></a>
                <a href="https://www.facebook.com/EstefaniaTZ"><i class="fa-brands fa-square-facebook " style="color: #144cad;"></i></a>

            </nav>
        </section>

    </footer>
    
</body>
</html>
</template>